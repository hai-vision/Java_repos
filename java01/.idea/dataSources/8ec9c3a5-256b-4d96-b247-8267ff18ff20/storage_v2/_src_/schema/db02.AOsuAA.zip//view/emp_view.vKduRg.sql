create definer = root@localhost view emp_view as
select `db02`.`emp`.`empno`  AS `empno`,
       `db02`.`emp`.`ename`  AS `ename`,
       `db02`.`emp`.`job`    AS `job`,
       `db02`.`emp`.`deptno` AS `deptno`
from `db02`.`emp`;

