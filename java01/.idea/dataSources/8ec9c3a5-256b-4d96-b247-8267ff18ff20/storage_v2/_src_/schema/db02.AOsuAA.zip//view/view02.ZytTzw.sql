create definer = root@localhost view view02 as
select `db02`.`emp`.`empno`      AS `empno`,
       `db02`.`emp`.`ename`      AS `ename`,
       `db02`.`dept`.`dname`     AS `dname`,
       `db02`.`salgrade`.`grade` AS `grade`
from `db02`.`emp`
         join `db02`.`dept`
         join `db02`.`salgrade`
where ((`db02`.`emp`.`deptno` = `db02`.`dept`.`deptno`) and
       (`db02`.`emp`.`sal` between `db02`.`salgrade`.`losal` and `db02`.`salgrade`.`hisal`));

