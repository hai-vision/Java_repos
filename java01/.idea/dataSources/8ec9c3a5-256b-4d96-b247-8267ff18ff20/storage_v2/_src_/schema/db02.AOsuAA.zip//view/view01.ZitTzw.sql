create definer = root@localhost view view01 as
select `db02`.`emp`.`empno` AS `empno`, `db02`.`emp`.`ename` AS `ename`, `db02`.`dept`.`dname` AS `dname`
from `db02`.`emp`
         join `db02`.`dept`
where (`db02`.`emp`.`deptno` = `db02`.`dept`.`deptno`);

